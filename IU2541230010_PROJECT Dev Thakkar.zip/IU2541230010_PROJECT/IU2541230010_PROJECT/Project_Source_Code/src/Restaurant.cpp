#include "Restaurant.h"
#include "BeverageItem.h"
#include "Common.h"
#include "FoodItem.h"
#include "Utils.h"

#include <iomanip>
#include <iostream>

static const int INITIAL_CAPACITY = 4;      // small on purpose so growth is easy to demonstrate

// ======================= construction / destruction =======================

Restaurant::Restaurant(const std::string& name, const std::string& dataDir)
    : restaurantName(name), fileManager(dataDir),
      menu(nullptr), menuCount(0), menuCap(0),
      customers(nullptr), customerCount(0), customerCap(0),
      orders(nullptr), orderCount(0), orderCap(0),
      bills(nullptr), billCount(0), billCap(0),
      nextItemId(1), nextCustomerId(1), nextOrderId(1), nextBillId(1) {
    initArrays();
}

Restaurant::~Restaurant() {
    std::cout << "\n[Memory] Releasing " << menuCount << " menu items, " << customerCount
              << " customers, " << orderCount << " orders and " << billCount << " bills (delete / delete[]).\n";
    freeAll();
}

void Restaurant::initArrays() {
    menu = new MenuItem*[INITIAL_CAPACITY];
    menuCap = INITIAL_CAPACITY;
    menuCount = 0;
    customers = new Customer[INITIAL_CAPACITY];
    customerCap = INITIAL_CAPACITY;
    customerCount = 0;
    orders = new Order[INITIAL_CAPACITY];
    orderCap = INITIAL_CAPACITY;
    orderCount = 0;
    bills = new Bill[INITIAL_CAPACITY];
    billCap = INITIAL_CAPACITY;
    billCount = 0;
}

void Restaurant::freeAll() {
    for (int i = 0; i < menuCount; ++i) delete menu[i];   // virtual destructor runs the right one
    delete[] menu;
    delete[] customers;
    delete[] orders;
    delete[] bills;
    menu = nullptr;
    customers = nullptr;
    orders = nullptr;
    bills = nullptr;
    menuCount = menuCap = customerCount = customerCap = 0;
    orderCount = orderCap = billCount = billCap = 0;
}

void Restaurant::clearAll() {
    freeAll();
    initArrays();
    nextItemId = nextCustomerId = nextOrderId = nextBillId = 1;
}

// ======================= array growth (dynamic memory) =======================

void Restaurant::growMenu() {
    int newCap = menuCap * 2;
    MenuItem** bigger = new MenuItem*[newCap];
    for (int i = 0; i < menuCount; ++i) bigger[i] = menu[i];   // copy pointers only
    delete[] menu;
    menu = bigger;
    menuCap = newCap;
}

void Restaurant::growCustomers() {
    int newCap = customerCap * 2;
    Customer* bigger = new Customer[newCap];
    for (int i = 0; i < customerCount; ++i) bigger[i] = customers[i];
    delete[] customers;
    customers = bigger;
    customerCap = newCap;
}

void Restaurant::growOrders() {
    int newCap = orderCap * 2;
    Order* bigger = new Order[newCap];
    for (int i = 0; i < orderCount; ++i) bigger[i] = orders[i];   // Order::operator= makes deep copies
    delete[] orders;
    orders = bigger;
    orderCap = newCap;
}

void Restaurant::growBills() {
    int newCap = billCap * 2;
    Bill* bigger = new Bill[newCap];
    for (int i = 0; i < billCount; ++i) bigger[i] = bills[i];
    delete[] bills;
    bills = bigger;
    billCap = newCap;
}

// ======================= find helpers =======================

int Restaurant::findMenuIndex(int id) const {
    for (int i = 0; i < menuCount; ++i) if (menu[i]->getItemId() == id) return i;
    return -1;
}
int Restaurant::findCustomerIndex(int id) const {
    for (int i = 0; i < customerCount; ++i) if (customers[i].getCustomerId() == id) return i;
    return -1;
}
int Restaurant::findOrderIndex(int id) const {
    for (int i = 0; i < orderCount; ++i) if (orders[i].getOrderId() == id) return i;
    return -1;
}
int Restaurant::findBillIndex(int id) const {
    for (int i = 0; i < billCount; ++i) if (bills[i].getBillId() == id) return i;
    return -1;
}

bool Restaurant::menuNameExists(const std::string& name, int exceptId) const {
    for (int i = 0; i < menuCount; ++i)
        if (menu[i]->getItemId() != exceptId &&
            Utils::toLower(menu[i]->getName()) == Utils::toLower(name)) return true;
    return false;
}

std::string Restaurant::customerNameOf(int customerId) const {
    int idx = findCustomerIndex(customerId);
    return idx >= 0 ? customers[idx].getName() : std::string("(deleted customer)");
}

// ======================= 1. ADD =======================

void Restaurant::addMenuItem() {
    std::cout << "\n--- Add Menu Item ---\n  1. Food item\n  2. Beverage\n";
    int type = Input::readInt("Choose type (1-2): ", 1, 2);
    std::string name = Input::readName("Item name (max 22 chars): ", 22);
    if (menuNameExists(name)) throw RestaurantException("A menu item named '" + name + "' already exists.");
    std::string category = Input::readName("Category (max 12 chars, e.g. Starter): ", 12);
    double price = Input::readDouble("Price in Rs. (1 - 10000): ", 1, 10000);

    if (menuCount == menuCap) growMenu();               // grow BEFORE creating the object (no leak possible)
    MenuItem* item = nullptr;
    if (type == 1) {
        bool veg = Input::readYesNo("Is it vegetarian?");
        int spice = Input::readInt("Spice level (1 = Mild, 2 = Medium, 3 = Hot): ", 1, 3);
        item = new FoodItem(nextItemId, name, category, price, veg, spice);
    } else {
        int size = Input::readInt("Size in ml (50 - 2000): ", 50, 2000);
        bool cold = Input::readYesNo("Is it served cold?");
        item = new BeverageItem(nextItemId, name, category, price, size, cold);
    }
    menu[menuCount++] = item;
    ++nextItemId;
    std::cout << "  Menu item added successfully:\n";
    MenuItem::printHeader();
    item->display();
    std::cout << "+-----+------------------------+-----------+--------------+----------+------+------------------------+\n";
}

void Restaurant::addCustomer() {
    std::cout << "\n--- Add Customer ---\n";
    std::string name = Input::readName("Customer name (max 30 chars): ", 30);
    std::string phone = Input::readPhone("Phone number (10 digits): ");
    for (int i = 0; i < customerCount; ++i)
        if (customers[i].getPhone() == phone)
            throw RestaurantException("A customer with this phone number already exists (ID " +
                                      std::to_string(customers[i].getCustomerId()) + ").");
    if (customerCount == customerCap) growCustomers();
    customers[customerCount++] = Customer(nextCustomerId, name, phone);
    std::cout << "  Customer added successfully with ID " << nextCustomerId << ".\n";
    ++nextCustomerId;
}

// ======================= 2. DISPLAY =======================

void Restaurant::displayMenu() const {
    std::cout << "\n--- Menu (" << menuCount << " items) ---\n";
    if (menuCount == 0) { std::cout << "  No menu items yet.\n"; return; }
    MenuItem::printHeader();
    for (int i = 0; i < menuCount; ++i) menu[i]->display();     // runtime polymorphism
    std::cout << "+-----+------------------------+-----------+--------------+----------+------+------------------------+\n";
}

void Restaurant::displayCustomers() const {
    std::cout << "\n--- Customers (" << customerCount << ") ---\n";
    if (customerCount == 0) { std::cout << "  No customers yet.\n"; return; }
    Customer::printHeader();
    for (int i = 0; i < customerCount; ++i) customers[i].display();
    std::cout << "+-----+--------------------------------+------------+\n";
}

void Restaurant::displayOrders() const {
    std::cout << "\n--- Orders (" << orderCount << ") ---\n";
    if (orderCount == 0) { std::cout << "  No orders yet.\n"; return; }
    Order::printRowHeader();
    for (int i = 0; i < orderCount; ++i) orders[i].displayRow(customerNameOf(orders[i].getCustomerId()));
    std::cout << "+-------+-------------+--------------------------+-------+-----------+------------+\n";
}

void Restaurant::displayBills() const {
    std::cout << "\n--- Bills (" << billCount << ") ---\n";
    if (billCount == 0) { std::cout << "  No bills yet.\n"; return; }
    Bill::printRowHeader();
    for (int i = 0; i < billCount; ++i) bills[i].displayRow();
    std::cout << "+------+-------+-----------+----------+-----------+--------+---------+\n";
}

// ======================= 3. SEARCH =======================

void Restaurant::searchMenuItem() const {
    std::cout << "\n--- Search Menu ---\n  1. By item ID\n  2. By name (keyword)\n  3. By category\n";
    int mode = Input::readInt("Search by (1-3): ", 1, 3);
    int found = 0;
    if (mode == 1) {
        int id = Input::readInt("Item ID: ", 1, 999999);
        int idx = findMenuIndex(id);
        if (idx >= 0) { MenuItem::printHeader(); menu[idx]->display(); found = 1; }
    } else {
        std::string key = Input::readLine(mode == 2 ? "Name keyword: " : "Category keyword: ");
        if (key.empty()) throw RestaurantException("Search text cannot be empty.");
        for (int i = 0; i < menuCount; ++i) {
            const std::string& field = (mode == 2) ? menu[i]->getName() : menu[i]->getCategory();
            if (Utils::containsIgnoreCase(field, key)) {
                if (found == 0) MenuItem::printHeader();
                menu[i]->display();
                ++found;
            }
        }
    }
    if (found == 0) std::cout << "  No matching menu items found.\n";
    else std::cout << "+-----+------------------------+-----------+--------------+----------+------+------------------------+\n"
                   << "  " << found << " item(s) found.\n";
}

void Restaurant::searchCustomer() const {
    std::cout << "\n--- Search Customer ---\n  1. By ID\n  2. By name (keyword)\n  3. By phone\n";
    int mode = Input::readInt("Search by (1-3): ", 1, 3);
    int found = 0;
    int wantedId = 0;
    std::string key;
    if (mode == 1) wantedId = Input::readInt("Customer ID: ", 1, 999999);
    else {
        key = Input::readLine(mode == 2 ? "Name keyword: " : "Phone (full or partial): ");
        if (key.empty()) throw RestaurantException("Search text cannot be empty.");
    }
    for (int i = 0; i < customerCount; ++i) {
        bool match = (mode == 1) ? (customers[i].getCustomerId() == wantedId)
                   : (mode == 2) ? Utils::containsIgnoreCase(customers[i].getName(), key)
                                 : (customers[i].getPhone().find(key) != std::string::npos);
        if (match) {
            if (found == 0) Customer::printHeader();
            customers[i].display();
            ++found;
        }
    }
    if (found == 0) std::cout << "  No matching customers found.\n";
    else std::cout << "+-----+--------------------------------+------------+\n  " << found << " customer(s) found.\n";
}

void Restaurant::searchOrder() const {
    std::cout << "\n--- Search Order ---\n  1. By order ID (full details)\n  2. By customer ID\n";
    int mode = Input::readInt("Search by (1-2): ", 1, 2);
    if (mode == 1) {
        int id = Input::readInt("Order ID: ", 1, 999999);
        int idx = findOrderIndex(id);
        if (idx < 0) { std::cout << "  No order found with ID " << id << ".\n"; return; }
        orders[idx].display(customerNameOf(orders[idx].getCustomerId()));
    } else {
        int cid = Input::readInt("Customer ID: ", 1, 999999);
        int found = 0;
        for (int i = 0; i < orderCount; ++i) {
            if (orders[i].getCustomerId() == cid) {
                if (found == 0) Order::printRowHeader();
                orders[i].displayRow(customerNameOf(cid));
                ++found;
            }
        }
        if (found == 0) std::cout << "  No orders found for customer ID " << cid << ".\n";
        else std::cout << "+-------+-------------+--------------------------+-------+-----------+------------+\n";
    }
}

void Restaurant::searchBill() const {
    std::cout << "\n--- Search Bill ---\n";
    int id = Input::readInt("Bill ID: ", 1, 999999);
    int idx = findBillIndex(id);
    if (idx < 0) { std::cout << "  No bill found with ID " << id << ".\n"; return; }
    int oi = findOrderIndex(bills[idx].getOrderId());
    if (oi < 0) throw RestaurantException("The order for this bill is missing.");
    bills[idx].printBill(orders[oi], customerNameOf(orders[oi].getCustomerId()));
}

// ======================= 4. UPDATE =======================

void Restaurant::updateMenuItem() {
    std::cout << "\n--- Update Menu Item ---\n";
    int id = Input::readInt("Item ID to update: ", 1, 999999);
    int idx = findMenuIndex(id);
    if (idx < 0) throw RestaurantException("No menu item with ID " + std::to_string(id) + ".");
    MenuItem::printHeader();
    menu[idx]->display();
    std::cout << "+-----+------------------------+-----------+--------------+----------+------+------------------------+\n"
              << "  1. Change price\n  2. Change name\n  3. Change category\n";
    int what = Input::readInt("What to update (1-3): ", 1, 3);
    if (what == 1) {
        double p = Input::readDouble("New price in Rs. (1 - 10000): ", 1, 10000);
        menu[idx]->updatePrice(p);
    } else if (what == 2) {
        std::string n = Input::readName("New name (max 22 chars): ", 22);
        if (menuNameExists(n, id)) throw RestaurantException("Another item already uses that name.");
        menu[idx]->setName(n);
    } else {
        menu[idx]->setCategory(Input::readName("New category (max 12 chars): ", 12));
    }
    std::cout << "  Updated successfully. Existing orders and bills keep the old price.\n";
    MenuItem::printHeader();
    menu[idx]->display();
    std::cout << "+-----+------------------------+-----------+--------------+----------+------+------------------------+\n";
}

void Restaurant::updateCustomer() {
    std::cout << "\n--- Update Customer ---\n";
    int id = Input::readInt("Customer ID to update: ", 1, 999999);
    int idx = findCustomerIndex(id);
    if (idx < 0) throw RestaurantException("No customer with ID " + std::to_string(id) + ".");
    Customer::printHeader();
    customers[idx].display();
    std::cout << "+-----+--------------------------------+------------+\n  1. Change name\n  2. Change phone\n";
    int what = Input::readInt("What to update (1-2): ", 1, 2);
    if (what == 1) {
        customers[idx].setName(Input::readName("New name (max 30 chars): ", 30));
    } else {
        std::string p = Input::readPhone("New phone (10 digits): ");
        for (int i = 0; i < customerCount; ++i)
            if (i != idx && customers[i].getPhone() == p)
                throw RestaurantException("Another customer already uses that phone number.");
        customers[idx].setPhone(p);
    }
    std::cout << "  Customer updated successfully.\n";
}

void Restaurant::updateOrder() {
    std::cout << "\n--- Update Order (add more items) ---\n";
    int id = Input::readInt("Order ID: ", 1, 999999);
    int idx = findOrderIndex(id);
    if (idx < 0) throw RestaurantException("No order with ID " + std::to_string(id) + ".");
    if (orders[idx].getStatus() != OrderStatus::OPEN)
        throw RestaurantException("Only OPEN orders can be changed (this order is " + orders[idx].statusText() + ").");
    int added = addLinesToOrder(orders[idx]);
    std::cout << "  " << added << " item(s) added.";
    orders[idx].display(customerNameOf(orders[idx].getCustomerId()));
}

// ======================= 5. DELETE =======================

void Restaurant::deleteMenuItem() {
    std::cout << "\n--- Delete Menu Item ---\n";
    int id = Input::readInt("Item ID to delete: ", 1, 999999);
    int idx = findMenuIndex(id);
    if (idx < 0) throw RestaurantException("No menu item with ID " + std::to_string(id) + ".");
    MenuItem::printHeader();
    menu[idx]->display();
    std::cout << "+-----+------------------------+-----------+--------------+----------+------+------------------------+\n";
    if (!Input::readYesNo("Delete this item?")) { std::cout << "  Cancelled. Nothing deleted.\n"; return; }
    delete menu[idx];                                   // free the object
    for (int i = idx; i < menuCount - 1; ++i) menu[i] = menu[i + 1];   // close the gap
    --menuCount;
    std::cout << "  Menu item deleted. (Old orders still show it, because lines keep their own copy.)\n";
}

void Restaurant::deleteCustomer() {
    std::cout << "\n--- Delete Customer ---\n";
    int id = Input::readInt("Customer ID to delete: ", 1, 999999);
    int idx = findCustomerIndex(id);
    if (idx < 0) throw RestaurantException("No customer with ID " + std::to_string(id) + ".");
    for (int i = 0; i < orderCount; ++i)
        if (orders[i].getCustomerId() == id)
            throw RestaurantException("Cannot delete: this customer has orders (e.g. order " +
                                      std::to_string(orders[i].getOrderId()) + "). Delete those orders first.");
    Customer::printHeader();
    customers[idx].display();
    std::cout << "+-----+--------------------------------+------------+\n";
    if (!Input::readYesNo("Delete this customer?")) { std::cout << "  Cancelled. Nothing deleted.\n"; return; }
    for (int i = idx; i < customerCount - 1; ++i) customers[i] = customers[i + 1];
    --customerCount;
    std::cout << "  Customer deleted.\n";
}

void Restaurant::deleteOrder() {
    std::cout << "\n--- Delete Order ---\n";
    int id = Input::readInt("Order ID to delete: ", 1, 999999);
    int idx = findOrderIndex(id);
    if (idx < 0) throw RestaurantException("No order with ID " + std::to_string(id) + ".");
    OrderStatus st = orders[idx].getStatus();
    if (st == OrderStatus::BILLED || st == OrderStatus::PAID)
        throw RestaurantException("A " + orders[idx].statusText() + " order has a bill and cannot be deleted.");
    orders[idx].display(customerNameOf(orders[idx].getCustomerId()));
    if (!Input::readYesNo("Delete this order?")) { std::cout << "  Cancelled. Nothing deleted.\n"; return; }
    for (int i = idx; i < orderCount - 1; ++i) orders[i] = orders[i + 1];   // deep copies via operator=
    --orderCount;
    std::cout << "  Order deleted.\n";
}

// ======================= 6. MAIN TRANSACTION =======================

// Asks for items until the user types 0. Returns how many were added.
int Restaurant::addLinesToOrder(Order& order) {
    int added = 0;
    displayMenu();
    while (true) {
        int id = Input::readInt("Item ID to add (0 = finish): ", 0, 999999);
        if (id == 0) break;
        int idx = findMenuIndex(id);
        if (idx < 0) { std::cout << "  [Error] No menu item with ID " << id << ".\n"; continue; }
        int qty = Input::readInt("Quantity (1-50): ", 1, 50);
        const MenuItem* m = menu[idx];
        try {
            order.addItem(m->getItemId(), m->getName(), m->getPrice(), m->getTaxRate(), qty);
            ++added;
            std::cout << "  Added " << qty << " x " << m->getName() << ".  Running total: "
                      << Utils::money(order.getTotal()) << "\n";
        } catch (const RestaurantException& e) {
            std::cout << "  [Error] " << e.what() << "\n";
        }
    }
    return added;
}

void Restaurant::createOrder() {
    std::cout << "\n--- Place New Order ---\n";
    if (menuCount == 0) throw RestaurantException("The menu is empty. Add menu items first.");
    if (customerCount == 0) throw RestaurantException("There are no customers. Add a customer first.");
    displayCustomers();
    int cid = Input::readInt("Customer ID: ", 1, 999999);
    if (findCustomerIndex(cid) < 0) throw RestaurantException("No customer with ID " + std::to_string(cid) + ".");

    Order order(nextOrderId, cid);
    addLinesToOrder(order);
    if (order.getLineCount() == 0) { std::cout << "  No items were added. Order discarded.\n"; return; }

    if (orderCount == orderCap) growOrders();
    orders[orderCount++] = order;                       // deep copy into the array
    ++nextOrderId;
    std::cout << "  Order placed successfully.";
    order.display(customerNameOf(cid));
}

void Restaurant::generateBill() {
    std::cout << "\n--- Generate Bill ---\n";
    int oid = Input::readInt("Order ID: ", 1, 999999);
    int oi = findOrderIndex(oid);
    if (oi < 0) throw RestaurantException("No order with ID " + std::to_string(oid) + ".");
    Order& order = orders[oi];
    if (order.getStatus() != OrderStatus::OPEN)
        throw RestaurantException("Only OPEN orders can be billed (this order is " + order.statusText() + ").");
    if (order.getLineCount() == 0) throw RestaurantException("This order has no items.");

    double pct = Input::readDouble("Discount percent (0 - 100, enter 0 for none): ", 0, 100);
    if (billCount == billCap) growBills();
    bills[billCount] = Bill(nextBillId, oid, order.getSubtotal(), order.getTax(), pct);
    order.setStatus(OrderStatus::BILLED);
    ++billCount;
    ++nextBillId;
    bills[billCount - 1].printBill(order, customerNameOf(order.getCustomerId()));
}

void Restaurant::payBill() {
    std::cout << "\n--- Pay Bill ---\n";
    int bid = Input::readInt("Bill ID: ", 1, 999999);
    int bi = findBillIndex(bid);
    if (bi < 0) throw RestaurantException("No bill with ID " + std::to_string(bid) + ".");
    Bill& bill = bills[bi];
    if (bill.isPaid()) throw RestaurantException("This bill is already paid.");
    int oi = findOrderIndex(bill.getOrderId());
    if (oi < 0) throw RestaurantException("The order for this bill is missing.");

    bill.printBill(orders[oi], customerNameOf(orders[oi].getCustomerId()));
    std::cout << "  1. Cash\n  2. Card\n  3. UPI\n";
    int mode = Input::readInt("Payment mode (1-3): ", 1, 3);
    double given = Input::readDouble("Amount received in Rs.: ", 0, 10000000);
    if (given + 0.0001 < bill.getAmount())
        throw RestaurantException("Insufficient amount. Bill is " + Utils::money(bill.getAmount()) +
                                  " but only " + Utils::money(given) + " was received.");
    const char* modes[] = {"", "Cash", "Card", "UPI"};
    bill.markPaid(modes[mode]);
    orders[oi].setStatus(OrderStatus::PAID);
    std::cout << "  Payment successful via " << modes[mode] << ". Change to return: "
              << Utils::money(given - bill.getAmount()) << "\n";
}

void Restaurant::cancelOrder() {
    std::cout << "\n--- Cancel Order ---\n";
    int id = Input::readInt("Order ID to cancel: ", 1, 999999);
    int idx = findOrderIndex(id);
    if (idx < 0) throw RestaurantException("No order with ID " + std::to_string(id) + ".");
    if (orders[idx].getStatus() != OrderStatus::OPEN)
        throw RestaurantException("Only OPEN orders can be cancelled (this order is " + orders[idx].statusText() + ").");
    if (!Input::readYesNo("Cancel order " + std::to_string(id) + "?")) { std::cout << "  Order kept.\n"; return; }
    orders[idx].setStatus(OrderStatus::CANCELLED);
    std::cout << "  Order " << id << " cancelled.\n";
}

// ======================= 7. REPORT =======================

void Restaurant::showReport() const {
    int foodCount = 0, drinkCount = 0;
    for (int i = 0; i < menuCount; ++i) {
        if (menu[i]->getType() == "Food") ++foodCount; else ++drinkCount;
    }
    int open = 0, billed = 0, paidO = 0, cancelled = 0;
    for (int i = 0; i < orderCount; ++i) {
        switch (orders[i].getStatus()) {
            case OrderStatus::OPEN:      ++open; break;
            case OrderStatus::BILLED:    ++billed; break;
            case OrderStatus::PAID:      ++paidO; break;
            case OrderStatus::CANCELLED: ++cancelled; break;
        }
    }
    double revenue = 0, outstanding = 0, discounts = 0;
    int paidBills = 0, unpaidBills = 0;
    for (int i = 0; i < billCount; ++i) {
        discounts += bills[i].getDiscount();
        if (bills[i].isPaid()) { revenue += bills[i].getAmount(); ++paidBills; }
        else { outstanding += bills[i].getAmount(); ++unpaidBills; }
    }

    // Best-selling item: count quantities per item over all non-cancelled orders.
    int totalLines = 0;
    for (int i = 0; i < orderCount; ++i) totalLines += orders[i].getLineCount();
    std::string bestName = "-";
    int bestQty = 0;
    if (totalLines > 0) {
        int* ids = new int[totalLines];                 // temporary dynamic arrays
        int* qtys = new int[totalLines];
        std::string* names = new std::string[totalLines];
        int distinct = 0;
        for (int i = 0; i < orderCount; ++i) {
            if (orders[i].getStatus() == OrderStatus::CANCELLED) continue;
            for (int j = 0; j < orders[i].getLineCount(); ++j) {
                const OrderLine& l = orders[i].getLine(j);
                int k = 0;
                while (k < distinct && ids[k] != l.itemId) ++k;
                if (k == distinct) { ids[k] = l.itemId; qtys[k] = 0; names[k] = l.name; ++distinct; }
                qtys[k] += l.qty;
            }
        }
        for (int k = 0; k < distinct; ++k)
            if (qtys[k] > bestQty) { bestQty = qtys[k]; bestName = names[k]; }
        delete[] ids;
        delete[] qtys;
        delete[] names;
    }

    // Top customer by amount actually paid.
    std::string topName = "-";
    double topSpend = 0;
    for (int c = 0; c < customerCount; ++c) {
        double spend = 0;
        for (int b = 0; b < billCount; ++b) {
            if (!bills[b].isPaid()) continue;
            int oi = findOrderIndex(bills[b].getOrderId());
            if (oi >= 0 && orders[oi].getCustomerId() == customers[c].getCustomerId()) spend += bills[b].getAmount();
        }
        if (spend > topSpend) { topSpend = spend; topName = customers[c].getName(); }
    }

    std::cout << "\n==================== RESTAURANT REPORT ====================\n"
              << "  Menu items      : " << menuCount << "  (Food: " << foodCount << ", Beverage: " << drinkCount << ")\n"
              << "  Customers       : " << customerCount << "\n"
              << "  Orders          : " << orderCount << "  (Open: " << open << ", Billed: " << billed
              << ", Paid: " << paidO << ", Cancelled: " << cancelled << ")\n"
              << "  Bills           : " << billCount << "  (Paid: " << paidBills << ", Unpaid: " << unpaidBills << ")\n"
              << "  Revenue (paid)  : " << Utils::money(revenue) << "\n"
              << "  Outstanding     : " << Utils::money(outstanding) << "\n"
              << "  Discounts given : " << Utils::money(discounts) << "\n";
    if (bestQty > 0) std::cout << "  Best-selling    : " << bestName << " (" << bestQty << " sold)\n";
    else std::cout << "  Best-selling    : -\n";
    if (topSpend > 0) std::cout << "  Top customer    : " << topName << " (" << Utils::money(topSpend) << " paid)\n";
    else std::cout << "  Top customer    : -\n";
    std::cout << "===========================================================\n";
}

// ======================= 8. SAVE / LOAD =======================

void Restaurant::saveData() const {
    fileManager.save(*this);
    std::cout << "  Saved to '" << fileManager.getDirectory() << "': " << menuCount << " menu items, "
              << customerCount << " customers, " << orderCount << " orders, " << billCount << " bills.\n";
}

void Restaurant::loadData() {
    int skipped = 0;
    bool found = fileManager.load(*this, skipped);
    if (!found) {
        std::cout << "  No saved data found in '" << fileManager.getDirectory() << "'. Starting with empty records.\n";
        return;
    }
    std::cout << "  Loaded from '" << fileManager.getDirectory() << "': " << menuCount << " menu items, "
              << customerCount << " customers, " << orderCount << " orders, " << billCount << " bills.";
    if (skipped > 0) std::cout << "  (" << skipped << " damaged record(s) skipped)";
    std::cout << "\n";
}

// ======================= access for FileManager =======================

int Restaurant::getMenuCount() const { return menuCount; }
int Restaurant::getCustomerCount() const { return customerCount; }
int Restaurant::getOrderCount() const { return orderCount; }
int Restaurant::getBillCount() const { return billCount; }

const MenuItem& Restaurant::getMenuItemAt(int i) const {
    if (i < 0 || i >= menuCount) throw RestaurantException("Menu index out of range.");
    return *menu[i];
}
const Customer& Restaurant::getCustomerAt(int i) const {
    if (i < 0 || i >= customerCount) throw RestaurantException("Customer index out of range.");
    return customers[i];
}
const Order& Restaurant::getOrderAt(int i) const {
    if (i < 0 || i >= orderCount) throw RestaurantException("Order index out of range.");
    return orders[i];
}
const Bill& Restaurant::getBillAt(int i) const {
    if (i < 0 || i >= billCount) throw RestaurantException("Bill index out of range.");
    return bills[i];
}

void Restaurant::adoptMenuItem(MenuItem* item) {
    if (findMenuIndex(item->getItemId()) >= 0) {
        int id = item->getItemId();
        delete item;                                    // we own it, so we must free it before refusing
        throw RestaurantException("Duplicate menu item ID " + std::to_string(id) + ".");
    }
    if (menuCount == menuCap) {
        try { growMenu(); } catch (...) { delete item; throw; }
    }
    menu[menuCount++] = item;
}

void Restaurant::appendCustomer(const Customer& c) {
    if (findCustomerIndex(c.getCustomerId()) >= 0)
        throw RestaurantException("Duplicate customer ID " + std::to_string(c.getCustomerId()) + ".");
    if (customerCount == customerCap) growCustomers();
    customers[customerCount++] = c;
}

void Restaurant::appendOrder(const Order& o) {
    if (findOrderIndex(o.getOrderId()) >= 0)
        throw RestaurantException("Duplicate order ID " + std::to_string(o.getOrderId()) + ".");
    if (orderCount == orderCap) growOrders();
    orders[orderCount++] = o;
}

void Restaurant::appendBill(const Bill& b) {
    if (findBillIndex(b.getBillId()) >= 0)
        throw RestaurantException("Duplicate bill ID " + std::to_string(b.getBillId()) + ".");
    if (billCount == billCap) growBills();
    bills[billCount++] = b;
}

void Restaurant::restoreCounters() {
    nextItemId = nextCustomerId = nextOrderId = nextBillId = 1;
    for (int i = 0; i < menuCount; ++i) if (menu[i]->getItemId() >= nextItemId) nextItemId = menu[i]->getItemId() + 1;
    for (int i = 0; i < customerCount; ++i) if (customers[i].getCustomerId() >= nextCustomerId) nextCustomerId = customers[i].getCustomerId() + 1;
    for (int i = 0; i < orderCount; ++i) if (orders[i].getOrderId() >= nextOrderId) nextOrderId = orders[i].getOrderId() + 1;
    for (int i = 0; i < billCount; ++i) if (bills[i].getBillId() >= nextBillId) nextBillId = bills[i].getBillId() + 1;
}
