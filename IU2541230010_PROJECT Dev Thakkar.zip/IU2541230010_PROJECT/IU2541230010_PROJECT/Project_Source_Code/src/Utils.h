// Utils.h - small helper functions: string utilities and validated console input
#ifndef UTILS_H
#define UTILS_H

#include <string>
#include <vector>

namespace Utils {
    std::string trim(const std::string& s);
    std::string toLower(const std::string& s);
    bool containsIgnoreCase(const std::string& text, const std::string& key);
    std::vector<std::string> split(const std::string& s, char delim);
    int toInt(const std::string& s);          // throws RestaurantException on bad input
    double toDouble(const std::string& s);    // throws RestaurantException on bad input
    std::string money(double value);          // e.g. "Rs. 1234.50"
    std::string currentDateTime();            // e.g. "11-10-2026 14:35"
}

namespace Input {
    std::string readLine(const std::string& prompt);
    int readInt(const std::string& prompt, int lo, int hi);
    double readDouble(const std::string& prompt, double lo, double hi);
    std::string readName(const std::string& prompt, std::size_t maxLen);
    std::string readPhone(const std::string& prompt);
    bool readYesNo(const std::string& prompt);
}

#endif
