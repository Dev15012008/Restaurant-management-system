// main.cpp - creates the Restaurant system, shows the menus and calls system functions.
// All real logic lives in the classes; main only routes the user's choices.
#include <iostream>
#include <new>

#include "Common.h"
#include "Restaurant.h"
#include "Utils.h"

static void showMainMenu() {
    std::cout << "\n=============================================\n"
              << "      RESTAURANT MANAGEMENT SYSTEM\n"
              << "=============================================\n"
              << "  1. Add Record\n"
              << "  2. Display Records\n"
              << "  3. Search Record\n"
              << "  4. Update Record\n"
              << "  5. Delete Record\n"
              << "  6. Main Transaction (Order / Bill / Payment)\n"
              << "  7. Report\n"
              << "  8. Save / Load\n"
              << "  9. Exit\n"
              << "=============================================\n";
}

static void handleChoice(Restaurant& r, int choice) {
    switch (choice) {
    case 1: {
        std::cout << "\n  1. Menu Item\n  2. Customer\n  0. Back\n";
        int c = Input::readInt("Add which record? ", 0, 2);
        if (c == 1) r.addMenuItem(); else if (c == 2) r.addCustomer();
        break;
    }
    case 2: {
        std::cout << "\n  1. Menu\n  2. Customers\n  3. Orders\n  4. Bills\n  0. Back\n";
        int c = Input::readInt("Display which records? ", 0, 4);
        if (c == 1) r.displayMenu(); else if (c == 2) r.displayCustomers();
        else if (c == 3) r.displayOrders(); else if (c == 4) r.displayBills();
        break;
    }
    case 3: {
        std::cout << "\n  1. Menu Item\n  2. Customer\n  3. Order\n  4. Bill\n  0. Back\n";
        int c = Input::readInt("Search which record? ", 0, 4);
        if (c == 1) r.searchMenuItem(); else if (c == 2) r.searchCustomer();
        else if (c == 3) r.searchOrder(); else if (c == 4) r.searchBill();
        break;
    }
    case 4: {
        std::cout << "\n  1. Menu Item\n  2. Customer\n  3. Order (add items)\n  0. Back\n";
        int c = Input::readInt("Update which record? ", 0, 3);
        if (c == 1) r.updateMenuItem(); else if (c == 2) r.updateCustomer(); else if (c == 3) r.updateOrder();
        break;
    }
    case 5: {
        std::cout << "\n  1. Menu Item\n  2. Customer\n  3. Order\n  0. Back\n";
        int c = Input::readInt("Delete which record? ", 0, 3);
        if (c == 1) r.deleteMenuItem(); else if (c == 2) r.deleteCustomer(); else if (c == 3) r.deleteOrder();
        break;
    }
    case 6: {
        std::cout << "\n  1. Place New Order\n  2. Generate Bill\n  3. Pay Bill\n  4. Cancel Order\n  0. Back\n";
        int c = Input::readInt("Choose transaction: ", 0, 4);
        if (c == 1) r.createOrder(); else if (c == 2) r.generateBill();
        else if (c == 3) r.payBill(); else if (c == 4) r.cancelOrder();
        break;
    }
    case 7:
        r.showReport();
        break;
    case 8: {
        std::cout << "\n  1. Save data to files\n  2. Load data from files\n  0. Back\n";
        int c = Input::readInt("Choose: ", 0, 2);
        if (c == 1) r.saveData();
        else if (c == 2) {
            if (Input::readYesNo("Loading replaces the records in memory. Continue?")) r.loadData();
        }
        break;
    }
    default:
        break;
    }
}

int main(int argc, char* argv[]) {
    std::string dataDir = (argc > 1) ? argv[1] : "Data";    // optional: restaurant <data-folder>
    try {
        Restaurant restaurant("Spice Garden", dataDir);
        std::cout << "Starting Restaurant Management System...\n";
        restaurant.loadData();                               // load existing records at start-up

        bool running = true;
        while (running) {
            showMainMenu();
            int choice = Input::readInt("Enter your choice (1-9): ", 1, 9);
            if (choice == 9) {
                if (Input::readYesNo("Save all changes before exit?")) {
                    try { restaurant.saveData(); }
                    catch (const RestaurantException& e) { std::cout << "  [Error] " << e.what() << "\n"; }
                }
                std::cout << "Thank you. Goodbye!\n";
                running = false;
                continue;
            }
            try {
                handleChoice(restaurant, choice);
            } catch (const InputClosedException&) {
                throw;                                       // input ended: leave the loop
            } catch (const RestaurantException& e) {
                std::cout << "  [Error] " << e.what() << "\n";
            } catch (const std::bad_alloc&) {
                std::cout << "  [Error] Out of memory.\n";
            }
        }
    } catch (const InputClosedException&) {
        std::cout << "\nInput closed. Exiting without saving.\n";
    } catch (const std::exception& e) {
        std::cerr << "Fatal error: " << e.what() << "\n";
        return 1;
    }
    return 0;
}
