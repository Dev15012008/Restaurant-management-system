#include "FoodItem.h"
#include "Common.h"

#include <iomanip>
#include <sstream>

FoodItem::FoodItem() : MenuItem(), isVeg(true), spiceLevel(1) {}

FoodItem::FoodItem(int id, const std::string& n, const std::string& c,
                   double p, bool veg, int spice)
    : MenuItem(id, n, c, p), isVeg(veg), spiceLevel(spice) {
    if (spice < 1 || spice > 3) throw RestaurantException("Spice level must be 1 (Mild), 2 (Medium) or 3 (Hot).");
}

FoodItem::~FoodItem() {}

bool FoodItem::getIsVeg() const { return isVeg; }
int FoodItem::getSpiceLevel() const { return spiceLevel; }

double FoodItem::getTaxRate() const { return 0.05; }          // 5% on food
std::string FoodItem::getType() const { return "Food"; }

std::string FoodItem::getDetails() const {
    const char* levels[] = {"", "Mild", "Medium", "Hot"};
    return std::string(isVeg ? "Veg" : "Non-Veg") + ", " + levels[spiceLevel];
}

std::string FoodItem::serialize() const {
    std::ostringstream os;
    os << "F|" << itemId << "|" << name << "|" << category << "|"
       << std::fixed << std::setprecision(2) << price << "|" << (isVeg ? 1 : 0) << "|" << spiceLevel;
    return os.str();
}
