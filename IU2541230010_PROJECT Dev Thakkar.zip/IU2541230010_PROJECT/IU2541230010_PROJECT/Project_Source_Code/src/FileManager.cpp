#include "FileManager.h"
#include "Common.h"
#include "Restaurant.h"
#include "Utils.h"

#include <filesystem>
#include <fstream>
#include <iostream>

FileManager::FileManager(const std::string& dataDir) : dir(dataDir) {}

const std::string& FileManager::getDirectory() const { return dir; }

std::string FileManager::pathOf(const std::string& file) const {
    return dir + "/" + file;
}

void FileManager::save(const Restaurant& r) const {
    try {
        std::filesystem::create_directories(dir);
    } catch (const std::exception& e) {
        throw RestaurantException(std::string("Cannot create data folder '") + dir + "': " + e.what());
    }

    std::ofstream menu(pathOf("menu.txt"));
    std::ofstream cust(pathOf("customers.txt"));
    std::ofstream ord(pathOf("orders.txt"));
    std::ofstream bill(pathOf("bills.txt"));
    if (!menu || !cust || !ord || !bill)
        throw RestaurantException("Cannot open one of the data files for writing in '" + dir + "'.");

    for (int i = 0; i < r.getMenuCount(); ++i)     menu << r.getMenuItemAt(i).serialize() << "\n";   // polymorphic call
    for (int i = 0; i < r.getCustomerCount(); ++i) cust << r.getCustomerAt(i).serialize() << "\n";
    for (int i = 0; i < r.getOrderCount(); ++i)    ord  << r.getOrderAt(i).serialize() << "\n";
    for (int i = 0; i < r.getBillCount(); ++i)     bill << r.getBillAt(i).serialize() << "\n";

    if (!menu || !cust || !ord || !bill)
        throw RestaurantException("Error while writing data files.");
}

bool FileManager::load(Restaurant& r, int& skipped) const {
    skipped = 0;
    r.clearAll();
    bool foundAny = false;
    std::string line;

    // ---- menu ----
    {
        std::ifstream in(pathOf("menu.txt"));
        if (in) {
            foundAny = true;
            int lineNo = 0;
            while (std::getline(in, line)) {
                ++lineNo;
                line = Utils::trim(line);
                if (line.empty()) continue;
                try {
                    r.adoptMenuItem(MenuItem::fromString(line));
                } catch (const RestaurantException& e) {
                    std::cout << "  [Load warning] menu.txt line " << lineNo << ": " << e.what() << "\n";
                    ++skipped;
                }
            }
        }
    }
    // ---- customers ----
    {
        std::ifstream in(pathOf("customers.txt"));
        if (in) {
            foundAny = true;
            int lineNo = 0;
            while (std::getline(in, line)) {
                ++lineNo;
                line = Utils::trim(line);
                if (line.empty()) continue;
                try {
                    r.appendCustomer(Customer::fromString(line));
                } catch (const RestaurantException& e) {
                    std::cout << "  [Load warning] customers.txt line " << lineNo << ": " << e.what() << "\n";
                    ++skipped;
                }
            }
        }
    }
    // ---- orders (header line followed by its item lines) ----
    {
        std::ifstream in(pathOf("orders.txt"));
        if (in) {
            foundAny = true;
            int lineNo = 0;
            while (std::getline(in, line)) {
                ++lineNo;
                line = Utils::trim(line);
                if (line.empty()) continue;
                try {
                    int n = 0;
                    Order o = Order::parseHeader(line, n);
                    for (int i = 0; i < n; ++i) {
                        std::string l;
                        if (!std::getline(in, l)) throw RestaurantException("File ended inside an order record.");
                        ++lineNo;
                        o.loadLine(Utils::trim(l));
                    }
                    o.calculateTotal();
                    r.appendOrder(o);
                } catch (const RestaurantException& e) {
                    std::cout << "  [Load warning] orders.txt line " << lineNo << ": " << e.what() << "\n";
                    ++skipped;
                }
            }
        }
    }
    // ---- bills ----
    {
        std::ifstream in(pathOf("bills.txt"));
        if (in) {
            foundAny = true;
            int lineNo = 0;
            while (std::getline(in, line)) {
                ++lineNo;
                line = Utils::trim(line);
                if (line.empty()) continue;
                try {
                    r.appendBill(Bill::fromString(line));
                } catch (const RestaurantException& e) {
                    std::cout << "  [Load warning] bills.txt line " << lineNo << ": " << e.what() << "\n";
                    ++skipped;
                }
            }
        }
    }
    r.restoreCounters();
    return foundAny;
}
