#include "Bill.h"
#include "Common.h"
#include "Order.h"
#include "Utils.h"

#include <iomanip>
#include <iostream>
#include <sstream>

Bill::Bill()
    : billId(0), orderId(0), subtotal(0), tax(0), discountPercent(0), discount(0),
      amount(0), paid(false), paymentMode("-"), billDate("") {}

Bill::Bill(int bid, int oid, double sub, double t, double pct)
    : billId(bid), orderId(oid), subtotal(sub), tax(t), discountPercent(pct),
      discount(0), amount(0), paid(false), paymentMode("-"), billDate(Utils::currentDateTime()) {
    if (bid <= 0 || oid <= 0) throw RestaurantException("Bill and order IDs must be positive.");
    if (sub < 0 || t < 0) throw RestaurantException("Bill amounts cannot be negative.");
    if (pct < 0 || pct > 100) throw RestaurantException("Discount must be between 0 and 100 percent.");
    calculateTotal();
}

Bill::~Bill() {}

int Bill::getBillId() const { return billId; }
int Bill::getOrderId() const { return orderId; }
double Bill::getSubtotal() const { return subtotal; }
double Bill::getTax() const { return tax; }
double Bill::getDiscount() const { return discount; }
double Bill::getAmount() const { return amount; }
bool Bill::isPaid() const { return paid; }
const std::string& Bill::getPaymentMode() const { return paymentMode; }

void Bill::calculateTotal() {
    double gross = subtotal + tax;
    discount = gross * discountPercent / 100.0;
    amount = gross - discount;
}

void Bill::markPaid(const std::string& mode) {
    if (paid) throw RestaurantException("This bill is already paid.");
    paid = true;
    paymentMode = mode;
}

void Bill::printBill(const Order& order, const std::string& customerName) const {
    std::ios::fmtflags f = std::cout.flags();
    std::cout << "\n  ==============================================\n"
              << "               SPICE GARDEN RESTAURANT\n"
              << "  ==============================================\n"
              << "  Bill No : " << billId << "        Order No: " << orderId << "\n"
              << "  Date    : " << billDate << "\n"
              << "  Customer: " << customerName << "\n"
              << "  ----------------------------------------------\n"
              << "  " << std::left << std::setw(22) << "Item" << std::right << std::setw(5) << "Qty"
              << std::setw(9) << "Rate" << std::setw(10) << "Amount" << "\n"
              << "  ----------------------------------------------\n";
    for (int i = 0; i < order.getLineCount(); ++i) {
        const OrderLine& l = order.getLine(i);
        std::cout << "  " << std::left << std::setw(22) << l.name.substr(0, 22) << std::right
                  << std::setw(5) << l.qty << std::setw(9) << std::fixed << std::setprecision(2) << l.unitPrice
                  << std::setw(10) << l.qty * l.unitPrice << "\n";
    }
    std::cout << "  ----------------------------------------------\n"
              << "  " << std::left << std::setw(30) << "Subtotal" << std::right << std::setw(14) << subtotal << "\n"
              << "  " << std::left << std::setw(30) << "Tax (GST)" << std::right << std::setw(14) << tax << "\n"
              << "  " << std::left << std::setw(30) << ("Discount (" + [&] { std::ostringstream p; p << std::setprecision(4) << discountPercent; return p.str(); }() + "%)")
              << std::right << std::setw(14) << -discount << "\n"
              << "  ----------------------------------------------\n"
              << "  " << std::left << std::setw(30) << "AMOUNT PAYABLE" << std::right << std::setw(14) << amount << "\n"
              << "  Status  : " << (paid ? "PAID via " + paymentMode : std::string("UNPAID")) << "\n"
              << "  ==============================================\n";
    std::cout.flags(f);
}

void Bill::printRowHeader() {
    std::cout << "+------+-------+-----------+----------+-----------+--------+---------+\n"
              << "| Bill | Order |  Subtotal |      Tax |    Amount | Status | Mode    |\n"
              << "+------+-------+-----------+----------+-----------+--------+---------+\n";
}

void Bill::displayRow() const {
    std::ios::fmtflags f = std::cout.flags();
    std::cout << "| " << std::right << std::setw(4) << billId
              << " | " << std::setw(5) << orderId
              << " | " << std::setw(9) << std::fixed << std::setprecision(2) << subtotal
              << " | " << std::setw(8) << tax
              << " | " << std::setw(9) << amount
              << " | " << std::left << std::setw(6) << (paid ? "PAID" : "UNPAID")
              << " | " << std::setw(7) << paymentMode << " |\n";
    std::cout.flags(f);
}

// B|billId|orderId|subtotal|tax|discountPercent|paid|mode|date
std::string Bill::serialize() const {
    std::ostringstream os;
    os << "B|" << billId << "|" << orderId << "|" << std::fixed << std::setprecision(2) << subtotal
       << "|" << tax << "|" << discountPercent << "|" << (paid ? 1 : 0) << "|" << paymentMode << "|" << billDate;
    return os.str();
}

Bill Bill::fromString(const std::string& line) {
    std::vector<std::string> f = Utils::split(line, '|');
    if (f.size() != 9 || f[0] != "B") throw RestaurantException("Bill record must have 9 fields starting with B.");
    Bill b(Utils::toInt(f[1]), Utils::toInt(f[2]), Utils::toDouble(f[3]),
           Utils::toDouble(f[4]), Utils::toDouble(f[5]));
    b.paid = (Utils::toInt(f[6]) != 0);
    b.paymentMode = f[7];
    b.billDate = f[8];
    return b;
}
