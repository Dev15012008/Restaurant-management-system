#include "Customer.h"
#include "Common.h"
#include "Utils.h"

#include <cctype>
#include <iomanip>
#include <iostream>
#include <sstream>

static void checkPhone(const std::string& p) {
    bool ok = (p.size() == 10);
    for (char c : p) if (!std::isdigit(static_cast<unsigned char>(c))) ok = false;
    if (!ok) throw RestaurantException("Phone number must be exactly 10 digits.");
}

Customer::Customer() : customerId(0), name("Unknown"), phone("0000000000") {}

Customer::Customer(int id, const std::string& n, const std::string& p)
    : customerId(id), name(n), phone(p) {
    if (id <= 0) throw RestaurantException("Customer ID must be positive.");
    if (n.empty()) throw RestaurantException("Customer name cannot be empty.");
    checkPhone(p);
}

Customer::~Customer() {}

int Customer::getCustomerId() const { return customerId; }
const std::string& Customer::getName() const { return name; }
const std::string& Customer::getPhone() const { return phone; }

void Customer::setName(const std::string& newName) {
    if (newName.empty()) throw RestaurantException("Customer name cannot be empty.");
    name = newName;
}

void Customer::setPhone(const std::string& newPhone) {
    checkPhone(newPhone);
    phone = newPhone;
}

void Customer::printHeader() {
    std::ios::fmtflags f = std::cout.flags();
    std::cout << "+-----+--------------------------------+------------+\n"
              << "| " << std::left << std::setw(3) << "ID" << " | " << std::setw(30) << "Name"
              << " | " << std::setw(10) << "Phone" << " |\n"
              << "+-----+--------------------------------+------------+\n";
    std::cout.flags(f);
}

void Customer::display() const {
    std::ios::fmtflags f = std::cout.flags();
    std::cout << "| " << std::right << std::setw(3) << customerId
              << " | " << std::left << std::setw(30) << name
              << " | " << std::setw(10) << phone << " |\n";
    std::cout.flags(f);
}

std::string Customer::serialize() const {
    std::ostringstream os;
    os << "C|" << customerId << "|" << name << "|" << phone;
    return os.str();
}

Customer Customer::fromString(const std::string& line) {
    std::vector<std::string> f = Utils::split(line, '|');
    if (f.size() != 4 || f[0] != "C") throw RestaurantException("Customer record must be C|id|name|phone.");
    return Customer(Utils::toInt(f[1]), f[2], f[3]);
}
