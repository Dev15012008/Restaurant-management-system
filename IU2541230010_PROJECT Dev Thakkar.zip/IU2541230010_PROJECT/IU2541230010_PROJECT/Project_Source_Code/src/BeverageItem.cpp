#include "BeverageItem.h"
#include "Common.h"

#include <iomanip>
#include <sstream>

BeverageItem::BeverageItem() : MenuItem(), sizeMl(250), isCold(true) {}

BeverageItem::BeverageItem(int id, const std::string& n, const std::string& c,
                           double p, int size, bool cold)
    : MenuItem(id, n, c, p), sizeMl(size), isCold(cold) {
    if (size < 50 || size > 2000) throw RestaurantException("Beverage size must be between 50 and 2000 ml.");
}

BeverageItem::~BeverageItem() {}

int BeverageItem::getSizeMl() const { return sizeMl; }
bool BeverageItem::getIsCold() const { return isCold; }

double BeverageItem::getTaxRate() const { return 0.12; }      // 12% on beverages
std::string BeverageItem::getType() const { return "Beverage"; }

std::string BeverageItem::getDetails() const {
    std::ostringstream os;
    os << sizeMl << " ml, " << (isCold ? "Cold" : "Hot");
    return os.str();
}

std::string BeverageItem::serialize() const {
    std::ostringstream os;
    os << "B|" << itemId << "|" << name << "|" << category << "|"
       << std::fixed << std::setprecision(2) << price << "|" << sizeMl << "|" << (isCold ? 1 : 0);
    return os.str();
}
