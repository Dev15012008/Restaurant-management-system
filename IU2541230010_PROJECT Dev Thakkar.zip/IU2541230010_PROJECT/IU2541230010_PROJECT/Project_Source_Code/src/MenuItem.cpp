#include "MenuItem.h"
#include "BeverageItem.h"
#include "Common.h"
#include "FoodItem.h"
#include "Utils.h"

#include <iomanip>
#include <iostream>

MenuItem::MenuItem() : itemId(0), name("Unnamed"), category("General"), price(0.0) {}

MenuItem::MenuItem(int id, const std::string& n, const std::string& c, double p)
    : itemId(id), name(n), category(c), price(p) {
    if (id <= 0) throw RestaurantException("Item ID must be positive.");
    if (n.empty()) throw RestaurantException("Item name cannot be empty.");
    if (c.empty()) throw RestaurantException("Item category cannot be empty.");
    if (!(p > 0.0)) throw RestaurantException("Item price must be greater than zero.");
}

MenuItem::~MenuItem() {}

int MenuItem::getItemId() const { return itemId; }
const std::string& MenuItem::getName() const { return name; }
const std::string& MenuItem::getCategory() const { return category; }
double MenuItem::getPrice() const { return price; }

void MenuItem::setName(const std::string& newName) {
    if (newName.empty()) throw RestaurantException("Item name cannot be empty.");
    name = newName;
}

void MenuItem::setCategory(const std::string& newCategory) {
    if (newCategory.empty()) throw RestaurantException("Item category cannot be empty.");
    category = newCategory;
}

void MenuItem::updatePrice(double newPrice) {
    if (!(newPrice > 0.0)) throw RestaurantException("Item price must be greater than zero.");
    price = newPrice;
}

double MenuItem::getFinalPrice() const { return price * (1.0 + getTaxRate()); }

void MenuItem::printHeader() {
    std::ios::fmtflags f = std::cout.flags();
    std::cout << "+-----+------------------------+-----------+--------------+----------+------+------------------------+\n"
              << "| " << std::left << std::setw(3) << "ID" << " | " << std::setw(22) << "Name"
              << " | " << std::setw(9) << "Type" << " | " << std::setw(12) << "Category"
              << " | " << std::right << std::setw(8) << "Price" << " | " << std::setw(4) << "Tax"
              << " | " << std::left << std::setw(22) << "Details" << " |\n"
              << "+-----+------------------------+-----------+--------------+----------+------+------------------------+\n";
    std::cout.flags(f);
}

void MenuItem::display() const {
    std::ios::fmtflags f = std::cout.flags();
    std::cout << "| " << std::right << std::setw(3) << itemId
              << " | " << std::left << std::setw(22) << name
              << " | " << std::setw(9) << getType()                 // virtual call
              << " | " << std::setw(12) << category
              << " | " << std::right << std::setw(8) << std::fixed << std::setprecision(2) << price
              << " | " << std::setw(3) << static_cast<int>(getTaxRate() * 100.0 + 0.5) << "%"   // virtual call
              << " | " << std::left << std::setw(22) << getDetails() << " |\n";  // virtual call
    std::cout.flags(f);
}

// Record layout:  F|id|name|category|price|isVeg|spice     or     B|id|name|category|price|sizeMl|isCold
MenuItem* MenuItem::fromString(const std::string& line) {
    std::vector<std::string> f = Utils::split(line, '|');
    if (f.size() != 7) throw RestaurantException("Menu record must have 7 fields.");
    int id = Utils::toInt(f[1]);
    double price = Utils::toDouble(f[4]);
    int a = Utils::toInt(f[5]);
    int b = Utils::toInt(f[6]);
    if (f[0] == "F") return new FoodItem(id, f[2], f[3], price, a != 0, b);
    if (f[0] == "B") return new BeverageItem(id, f[2], f[3], price, a, b != 0);
    throw RestaurantException("Unknown menu item type '" + f[0] + "'.");
}
