// FileManager.h - reads / writes all records to text files inside the Data folder
#ifndef FILEMANAGER_H
#define FILEMANAGER_H

#include <string>

class Restaurant;

class FileManager {
private:
    std::string dir;                                  // data folder, e.g. "Data"
    std::string pathOf(const std::string& file) const;

public:
    explicit FileManager(const std::string& dataDir = "Data");

    const std::string& getDirectory() const;
    void save(const Restaurant& r) const;             // throws RestaurantException on I/O failure
    bool load(Restaurant& r, int& skippedRecords) const;   // false if no data files exist yet
};

#endif
