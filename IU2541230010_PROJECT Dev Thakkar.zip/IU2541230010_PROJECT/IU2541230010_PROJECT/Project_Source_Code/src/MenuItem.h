// MenuItem.h - abstract base class for everything that can be ordered
#ifndef MENUITEM_H
#define MENUITEM_H

#include <string>

class MenuItem {
protected:
    int itemId;
    std::string name;
    std::string category;
    double price;               // base price (before tax)

public:
    MenuItem();
    MenuItem(int itemId, const std::string& name, const std::string& category, double price);
    virtual ~MenuItem();        // virtual: derived objects are deleted through MenuItem*

    int getItemId() const;
    const std::string& getName() const;
    const std::string& getCategory() const;
    double getPrice() const;

    void setName(const std::string& newName);
    void setCategory(const std::string& newCategory);
    void updatePrice(double newPrice);
    double getFinalPrice() const;          // price + tax (uses the virtual getTaxRate)

    // ---- runtime polymorphism: each derived class gives its own behaviour ----
    virtual double getTaxRate() const = 0;
    virtual std::string getType() const = 0;
    virtual std::string getDetails() const = 0;
    virtual std::string serialize() const = 0;
    virtual void display() const;

    static void printHeader();
    static MenuItem* fromString(const std::string& line);   // factory used by FileManager
};

#endif
