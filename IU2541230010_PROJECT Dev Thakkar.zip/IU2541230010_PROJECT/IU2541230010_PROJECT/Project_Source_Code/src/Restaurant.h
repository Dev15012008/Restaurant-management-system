// Restaurant.h - the SYSTEM class: owns all records and implements every operation
#ifndef RESTAURANT_H
#define RESTAURANT_H

#include <string>

#include "Bill.h"
#include "Customer.h"
#include "FileManager.h"
#include "MenuItem.h"
#include "Order.h"

class Restaurant {
private:
    std::string restaurantName;
    FileManager fileManager;

    // ---- dynamic arrays (allocated with new[], grown when full, released in the destructor) ----
    MenuItem** menu;            // array of base-class pointers -> FoodItem / BeverageItem objects
    int menuCount, menuCap;
    Customer* customers;
    int customerCount, customerCap;
    Order* orders;
    int orderCount, orderCap;
    Bill* bills;
    int billCount, billCap;

    int nextItemId, nextCustomerId, nextOrderId, nextBillId;

    // ---- helpers ----
    void initArrays();
    void freeAll();
    void growMenu();
    void growCustomers();
    void growOrders();
    void growBills();
    int findMenuIndex(int id) const;
    int findCustomerIndex(int id) const;
    int findOrderIndex(int id) const;
    int findBillIndex(int id) const;
    bool menuNameExists(const std::string& name, int exceptId = -1) const;
    std::string customerNameOf(int customerId) const;
    int addLinesToOrder(Order& order);

    Restaurant(const Restaurant&);              // copying a Restaurant makes no sense -> disabled
    Restaurant& operator=(const Restaurant&);

public:
    Restaurant(const std::string& name, const std::string& dataDir);
    ~Restaurant();

    // 1. Add
    void addMenuItem();
    void addCustomer();
    // 2. Display
    void displayMenu() const;
    void displayCustomers() const;
    void displayOrders() const;
    void displayBills() const;
    // 3. Search
    void searchMenuItem() const;
    void searchCustomer() const;
    void searchOrder() const;
    void searchBill() const;
    // 4. Update
    void updateMenuItem();
    void updateCustomer();
    void updateOrder();
    // 5. Delete
    void deleteMenuItem();
    void deleteCustomer();
    void deleteOrder();
    // 6. Main transaction: order -> bill -> payment
    void createOrder();
    void generateBill();
    void payBill();
    void cancelOrder();
    // 7. Report
    void showReport() const;
    // 8. Save / Load
    void saveData() const;
    void loadData();

    // ---- read access used by FileManager ----
    int getMenuCount() const;
    int getCustomerCount() const;
    int getOrderCount() const;
    int getBillCount() const;
    const MenuItem& getMenuItemAt(int index) const;
    const Customer& getCustomerAt(int index) const;
    const Order& getOrderAt(int index) const;
    const Bill& getBillAt(int index) const;

    // ---- write access used by FileManager while loading ----
    void clearAll();
    void adoptMenuItem(MenuItem* item);         // takes ownership of the pointer
    void appendCustomer(const Customer& c);
    void appendOrder(const Order& o);
    void appendBill(const Bill& b);
    void restoreCounters();
};

#endif
