#include "Order.h"
#include "Common.h"
#include "Utils.h"

#include <iomanip>
#include <iostream>
#include <sstream>

Order::Order()
    : orderId(0), customerId(0), lines(nullptr), lineCount(0), lineCap(0),
      subtotal(0), tax(0), total(0), status(OrderStatus::OPEN) {}

Order::Order(int oid, int cid)
    : orderId(oid), customerId(cid), lines(nullptr), lineCount(0), lineCap(0),
      subtotal(0), tax(0), total(0), status(OrderStatus::OPEN) {
    if (oid <= 0) throw RestaurantException("Order ID must be positive.");
    if (cid <= 0) throw RestaurantException("Customer ID must be positive.");
}

Order::Order(const Order& other)
    : orderId(0), customerId(0), lines(nullptr), lineCount(0), lineCap(0),
      subtotal(0), tax(0), total(0), status(OrderStatus::OPEN) {
    copyFrom(other);
}

Order& Order::operator=(const Order& other) {
    if (this != &other) {
        delete[] lines;                         // release old memory first
        lines = nullptr;
        copyFrom(other);
    }
    return *this;
}

Order::~Order() {
    delete[] lines;                             // release the dynamic array
}

void Order::copyFrom(const Order& o) {
    orderId = o.orderId;
    customerId = o.customerId;
    lineCount = o.lineCount;
    lineCap = o.lineCount;
    subtotal = o.subtotal;
    tax = o.tax;
    total = o.total;
    status = o.status;
    lines = (lineCap > 0) ? new OrderLine[lineCap] : nullptr;
    for (int i = 0; i < lineCount; ++i) lines[i] = o.lines[i];
}

void Order::grow() {
    int newCap = (lineCap == 0) ? 4 : lineCap * 2;
    OrderLine* bigger = new OrderLine[newCap];
    for (int i = 0; i < lineCount; ++i) bigger[i] = lines[i];
    delete[] lines;
    lines = bigger;
    lineCap = newCap;
}

int Order::getOrderId() const { return orderId; }
int Order::getCustomerId() const { return customerId; }
int Order::getLineCount() const { return lineCount; }
double Order::getSubtotal() const { return subtotal; }
double Order::getTax() const { return tax; }
double Order::getTotal() const { return total; }
OrderStatus Order::getStatus() const { return status; }
void Order::setStatus(OrderStatus s) { status = s; }

const OrderLine& Order::getLine(int index) const {
    if (index < 0 || index >= lineCount) throw RestaurantException("Order line index out of range.");
    return lines[index];
}

std::string Order::statusText() const {
    switch (status) {
        case OrderStatus::OPEN:      return "OPEN";
        case OrderStatus::BILLED:    return "BILLED";
        case OrderStatus::PAID:      return "PAID";
        case OrderStatus::CANCELLED: return "CANCELLED";
    }
    return "UNKNOWN";
}

void Order::addItem(int itemId, const std::string& name, double unitPrice, double taxRate, int qty) {
    if (qty <= 0) throw RestaurantException("Quantity must be at least 1.");
    for (int i = 0; i < lineCount; ++i) {       // same item again? just increase quantity
        if (lines[i].itemId == itemId) {
            if (lines[i].qty + qty > 100) throw RestaurantException("Quantity of one item cannot exceed 100 per order.");
            lines[i].qty += qty;
            calculateTotal();
            return;
        }
    }
    if (lineCount == lineCap) grow();
    lines[lineCount].itemId = itemId;
    lines[lineCount].name = name;
    lines[lineCount].qty = qty;
    lines[lineCount].unitPrice = unitPrice;
    lines[lineCount].taxRate = taxRate;
    ++lineCount;
    calculateTotal();
}

void Order::calculateTotal() {
    subtotal = 0.0;
    tax = 0.0;
    for (int i = 0; i < lineCount; ++i) {
        double lineBase = lines[i].qty * lines[i].unitPrice;
        subtotal += lineBase;
        tax += lineBase * lines[i].taxRate;
    }
    total = subtotal + tax;
}

void Order::printRowHeader() {
    std::cout << "+-------+-------------+--------------------------+-------+-----------+------------+\n"
              << "| Order | Customer ID | Customer Name            | Items |     Total | Status     |\n"
              << "+-------+-------------+--------------------------+-------+-----------+------------+\n";
}

void Order::displayRow(const std::string& customerName) const {
    std::ios::fmtflags f = std::cout.flags();
    std::cout << "| " << std::right << std::setw(5) << orderId
              << " | " << std::setw(11) << customerId
              << " | " << std::left << std::setw(24) << customerName.substr(0, 24)
              << " | " << std::right << std::setw(5) << lineCount
              << " | " << std::setw(9) << std::fixed << std::setprecision(2) << total
              << " | " << std::left << std::setw(10) << statusText() << " |\n";
    std::cout.flags(f);
}

void Order::display(const std::string& customerName) const {
    std::ios::fmtflags f = std::cout.flags();
    std::cout << "\n  ORDER #" << orderId << "   Customer: " << customerName << " (ID " << customerId
              << ")   Status: " << statusText() << "\n"
              << "  +-----+------------------------+-----+-----------+------------+\n"
              << "  | ID  | Item                   | Qty |      Rate |     Amount |\n"
              << "  +-----+------------------------+-----+-----------+------------+\n";
    for (int i = 0; i < lineCount; ++i) {
        std::cout << "  | " << std::right << std::setw(3) << lines[i].itemId
                  << " | " << std::left << std::setw(22) << lines[i].name.substr(0, 22)
                  << " | " << std::right << std::setw(3) << lines[i].qty
                  << " | " << std::setw(9) << std::fixed << std::setprecision(2) << lines[i].unitPrice
                  << " | " << std::setw(10) << lines[i].qty * lines[i].unitPrice << " |\n";
    }
    std::cout << "  +-----+------------------------+-----+-----------+------------+\n"
              << "  Subtotal: " << Utils::money(subtotal) << "   Tax: " << Utils::money(tax)
              << "   TOTAL: " << Utils::money(total) << "\n";
    std::cout.flags(f);
}

// File layout:   O|orderId|customerId|status|lineCount     followed by lineCount lines:
//                L|itemId|qty|unitPrice|taxRate|name
std::string Order::serialize() const {
    std::ostringstream os;
    os << "O|" << orderId << "|" << customerId << "|" << static_cast<int>(status) << "|" << lineCount;
    for (int i = 0; i < lineCount; ++i) {
        os << "\nL|" << lines[i].itemId << "|" << lines[i].qty << "|"
           << std::fixed << std::setprecision(2) << lines[i].unitPrice << "|"
           << std::setprecision(4) << lines[i].taxRate << "|" << lines[i].name;
    }
    return os.str();
}

Order Order::parseHeader(const std::string& line, int& lineCount) {
    std::vector<std::string> f = Utils::split(line, '|');
    if (f.size() != 5 || f[0] != "O") throw RestaurantException("Order header must be O|id|customerId|status|lineCount.");
    Order o(Utils::toInt(f[1]), Utils::toInt(f[2]));
    int st = Utils::toInt(f[3]);
    if (st < 0 || st > 3) throw RestaurantException("Order status must be 0-3.");
    o.status = static_cast<OrderStatus>(st);
    lineCount = Utils::toInt(f[4]);
    if (lineCount < 0 || lineCount > 1000) throw RestaurantException("Invalid order line count.");
    return o;
}

void Order::loadLine(const std::string& line) {
    std::vector<std::string> f = Utils::split(line, '|');
    if (f.size() != 6 || f[0] != "L") throw RestaurantException("Order line must be L|itemId|qty|price|tax|name.");
    int id = Utils::toInt(f[1]);
    int qty = Utils::toInt(f[2]);
    double price = Utils::toDouble(f[3]);
    double tax = Utils::toDouble(f[4]);
    if (id <= 0 || qty <= 0 || price < 0 || tax < 0) throw RestaurantException("Order line has invalid values.");
    addItem(id, f[5], price, tax, qty);
}
