// Customer.h - a restaurant customer
#ifndef CUSTOMER_H
#define CUSTOMER_H

#include <string>

class Customer {
private:
    int customerId;
    std::string name;
    std::string phone;

public:
    Customer();
    Customer(int customerId, const std::string& name, const std::string& phone);
    ~Customer();

    int getCustomerId() const;
    const std::string& getName() const;
    const std::string& getPhone() const;

    void setName(const std::string& newName);
    void setPhone(const std::string& newPhone);   // validates 10 digits

    void display() const;
    std::string serialize() const;
    static void printHeader();
    static Customer fromString(const std::string& line);
};

#endif
