// Order.h - one customer order; owns a dynamically allocated array of order lines
#ifndef ORDER_H
#define ORDER_H

#include <string>

enum class OrderStatus { OPEN = 0, BILLED = 1, PAID = 2, CANCELLED = 3 };

// One line of an order. Name and prices are copied ("snapshot") when the item is
// added, so later menu changes never alter an existing order or bill.
struct OrderLine {
    int itemId;
    std::string name;
    int qty;
    double unitPrice;           // base price
    double taxRate;             // e.g. 0.05
    OrderLine() : itemId(0), qty(0), unitPrice(0.0), taxRate(0.0) {}
};

class Order {
private:
    int orderId;
    int customerId;
    OrderLine* lines;           // dynamic array (new[] / delete[])
    int lineCount;
    int lineCap;
    double subtotal;
    double tax;
    double total;
    OrderStatus status;

    void grow();
    void copyFrom(const Order& other);

public:
    Order();
    Order(int orderId, int customerId);
    Order(const Order& other);                  // deep copy (Rule of Three)
    Order& operator=(const Order& other);
    ~Order();

    int getOrderId() const;
    int getCustomerId() const;
    int getLineCount() const;
    const OrderLine& getLine(int index) const;
    double getSubtotal() const;
    double getTax() const;
    double getTotal() const;
    OrderStatus getStatus() const;
    void setStatus(OrderStatus s);
    std::string statusText() const;

    void addItem(int itemId, const std::string& name, double unitPrice, double taxRate, int qty);
    void calculateTotal();
    void display(const std::string& customerName) const;
    void displayRow(const std::string& customerName) const;
    static void printRowHeader();

    std::string serialize() const;              // header line + one L-line per item
    static Order parseHeader(const std::string& line, int& lineCount);
    void loadLine(const std::string& line);
};

#endif
