// Common.h - shared exception types used across the whole project
#ifndef COMMON_H
#define COMMON_H

#include <stdexcept>
#include <string>

// Base exception for every business / validation error in the system.
class RestaurantException : public std::runtime_error {
public:
    explicit RestaurantException(const std::string& message)
        : std::runtime_error(message) {}
};

// Thrown when standard input is closed (Ctrl+Z / Ctrl+D / end of piped input).
class InputClosedException : public RestaurantException {
public:
    InputClosedException() : RestaurantException("Input stream closed.") {}
};

#endif
