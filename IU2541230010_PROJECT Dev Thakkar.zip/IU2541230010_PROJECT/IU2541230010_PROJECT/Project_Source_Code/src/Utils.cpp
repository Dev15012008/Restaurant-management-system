#include "Utils.h"
#include "Common.h"

#include <algorithm>
#include <cctype>
#include <cstdlib>
#include <ctime>
#include <iomanip>
#include <iostream>
#include <sstream>

namespace Utils {

std::string trim(const std::string& s) {
    std::size_t b = 0, e = s.size();
    while (b < e && std::isspace(static_cast<unsigned char>(s[b]))) ++b;
    while (e > b && std::isspace(static_cast<unsigned char>(s[e - 1]))) --e;
    return s.substr(b, e - b);
}

std::string toLower(const std::string& s) {
    std::string r = s;
    std::transform(r.begin(), r.end(), r.begin(),
                   [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return r;
}

bool containsIgnoreCase(const std::string& text, const std::string& key) {
    return toLower(text).find(toLower(key)) != std::string::npos;
}

std::vector<std::string> split(const std::string& s, char delim) {
    std::vector<std::string> parts;
    std::string current;
    for (char c : s) {
        if (c == delim) { parts.push_back(current); current.clear(); }
        else current += c;
    }
    parts.push_back(current);
    return parts;
}

int toInt(const std::string& s) {
    try {
        std::size_t pos = 0;
        int v = std::stoi(s, &pos);
        if (pos != s.size()) throw RestaurantException("Please enter a valid whole number.");
        return v;
    } catch (const RestaurantException&) {
        throw;
    } catch (const std::exception&) {
        throw RestaurantException("Please enter a valid whole number.");
    }
}

double toDouble(const std::string& s) {
    try {
        std::size_t pos = 0;
        double v = std::stod(s, &pos);
        if (pos != s.size()) throw RestaurantException("Please enter a valid number.");
        return v;
    } catch (const RestaurantException&) {
        throw;
    } catch (const std::exception&) {
        throw RestaurantException("Please enter a valid number.");
    }
}

std::string money(double value) {
    std::ostringstream os;
    os << "Rs. " << std::fixed << std::setprecision(2) << value;
    return os.str();
}

std::string currentDateTime() {
    std::time_t t = std::time(nullptr);
    std::tm* lt = std::localtime(&t);
    char buf[32];
    std::strftime(buf, sizeof(buf), "%d-%m-%Y %H:%M", lt);
    return std::string(buf);
}

} // namespace Utils

namespace Input {

std::string readLine(const std::string& prompt) {
    std::cout << prompt;
    std::string s;
    if (!std::getline(std::cin, s)) throw InputClosedException();
    // Optional: when the environment variable RMS_ECHO is set (used for automated tests with
    // piped input) the typed answer is echoed, so saved transcripts read like a real session.
    static const bool echoInput = (std::getenv("RMS_ECHO") != nullptr);
    if (echoInput) std::cout << s << "\n";
    return Utils::trim(s);
}

int readInt(const std::string& prompt, int lo, int hi) {
    while (true) {
        std::string s = readLine(prompt);
        try {
            int v = Utils::toInt(s);
            if (v < lo || v > hi) {
                std::ostringstream m;
                m << "Value must be between " << lo << " and " << hi << ".";
                throw RestaurantException(m.str());
            }
            return v;
        } catch (const RestaurantException& e) {
            std::cout << "  [Error] " << e.what() << "\n";
        }
    }
}

double readDouble(const std::string& prompt, double lo, double hi) {
    while (true) {
        std::string s = readLine(prompt);
        try {
            double v = Utils::toDouble(s);
            if (!(v >= lo && v <= hi)) {
                std::ostringstream m;
                m << "Value must be between " << lo << " and " << hi << ".";
                throw RestaurantException(m.str());
            }
            return v;
        } catch (const RestaurantException& e) {
            std::cout << "  [Error] " << e.what() << "\n";
        }
    }
}

std::string readName(const std::string& prompt, std::size_t maxLen) {
    while (true) {
        std::string s = readLine(prompt);
        if (s.empty()) { std::cout << "  [Error] This field cannot be empty.\n"; continue; }
        if (s.size() > maxLen) {
            std::cout << "  [Error] Maximum " << maxLen << " characters allowed.\n";
            continue;
        }
        if (s.find('|') != std::string::npos) {
            std::cout << "  [Error] The character '|' is not allowed.\n";
            continue;
        }
        return s;
    }
}

std::string readPhone(const std::string& prompt) {
    while (true) {
        std::string s = readLine(prompt);
        bool ok = (s.size() == 10);
        for (char c : s) if (!std::isdigit(static_cast<unsigned char>(c))) ok = false;
        if (ok) return s;
        std::cout << "  [Error] Phone number must be exactly 10 digits.\n";
    }
}

bool readYesNo(const std::string& prompt) {
    while (true) {
        std::string s = Utils::toLower(readLine(prompt + " (y/n): "));
        if (s == "y" || s == "yes") return true;
        if (s == "n" || s == "no") return false;
        std::cout << "  [Error] Please type y or n.\n";
    }
}

} // namespace Input
