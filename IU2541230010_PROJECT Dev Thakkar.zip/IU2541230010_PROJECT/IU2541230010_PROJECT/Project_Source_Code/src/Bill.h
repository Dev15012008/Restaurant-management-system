// Bill.h - the invoice generated for one order
#ifndef BILL_H
#define BILL_H

#include <string>

class Order;

class Bill {
private:
    int billId;
    int orderId;
    double subtotal;
    double tax;
    double discountPercent;
    double discount;            // amount, derived from discountPercent
    double amount;              // final payable amount
    bool paid;
    std::string paymentMode;    // "Cash", "Card", "UPI" or "-"
    std::string billDate;

public:
    Bill();
    Bill(int billId, int orderId, double subtotal, double tax, double discountPercent);
    ~Bill();

    int getBillId() const;
    int getOrderId() const;
    double getSubtotal() const;
    double getTax() const;
    double getDiscount() const;
    double getAmount() const;
    bool isPaid() const;
    const std::string& getPaymentMode() const;

    void calculateTotal();
    void markPaid(const std::string& mode);
    void printBill(const Order& order, const std::string& customerName) const;
    void displayRow() const;
    static void printRowHeader();

    std::string serialize() const;
    static Bill fromString(const std::string& line);
};

#endif
