// BeverageItem.h - derived class: drinks (12% tax)
#ifndef BEVERAGEITEM_H
#define BEVERAGEITEM_H

#include "MenuItem.h"

class BeverageItem : public MenuItem {
private:
    int sizeMl;
    bool isCold;

public:
    BeverageItem();
    BeverageItem(int id, const std::string& name, const std::string& category,
                 double price, int sizeMl, bool isCold);
    ~BeverageItem();

    int getSizeMl() const;
    bool getIsCold() const;

    double getTaxRate() const override;
    std::string getType() const override;
    std::string getDetails() const override;
    std::string serialize() const override;
};

#endif
