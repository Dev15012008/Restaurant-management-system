// FoodItem.h - derived class: solid food (5% tax)
#ifndef FOODITEM_H
#define FOODITEM_H

#include "MenuItem.h"

class FoodItem : public MenuItem {
private:
    bool isVeg;
    int spiceLevel;             // 1 = Mild, 2 = Medium, 3 = Hot

public:
    FoodItem();
    FoodItem(int id, const std::string& name, const std::string& category,
             double price, bool isVeg, int spiceLevel);
    ~FoodItem();

    bool getIsVeg() const;
    int getSpiceLevel() const;

    double getTaxRate() const override;
    std::string getType() const override;
    std::string getDetails() const override;
    std::string serialize() const override;
};

#endif
