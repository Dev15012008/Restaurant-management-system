#!/usr/bin/env python3
"""Draws the Use Case Diagram and the two Sequence Diagrams as PNG files (matplotlib)."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse, FancyBboxPatch, Rectangle, FancyArrowPatch, Circle

BLUE, GREEN, GREY, ORANGE = "#E8F1FB", "#EAF6EA", "#F4F4F4", "#FDEBD0"

# ------------------------------------------------------------------ USE CASE
def stick_figure(ax, x, y, label):
    ax.add_patch(Circle((x, y + 0.55), 0.17, fill=False, lw=1.6, color="#222"))
    ax.plot([x, x], [y + 0.38, y - 0.15], color="#222", lw=1.6)
    ax.plot([x - 0.32, x + 0.32], [y + 0.22, y + 0.22], color="#222", lw=1.6)
    ax.plot([x, x - 0.28], [y - 0.15, y - 0.65], color="#222", lw=1.6)
    ax.plot([x, x + 0.28], [y - 0.15, y - 0.65], color="#222", lw=1.6)
    ax.text(x, y - 0.95, label, ha="center", va="top", fontsize=11, fontweight="bold")

def use_case():
    fig, ax = plt.subplots(figsize=(13, 9))
    ax.set_xlim(0, 13); ax.set_ylim(0, 9); ax.axis("off")
    ax.add_patch(Rectangle((3.0, 0.9), 7.0, 7.9, fc="#FFFEF7", ec="#333", lw=1.6))
    ax.text(6.5, 8.55, "Restaurant Management System", ha="center", va="center", fontsize=13, fontweight="bold")

    W_, H_ = 2.75, 0.78
    # (x, y) of each use case: shared ones on top, waiter's on the left, manager's on the right
    cases = {
        "Search Records":           (6.5, 7.75),
        "Display Records":          (6.5, 6.85),
        "Manage Customers\n(add / update / delete)": (4.95, 5.55),
        "Place Order":              (4.95, 4.55),
        "Update / Cancel Order":    (4.95, 3.55),
        "Generate Bill":            (4.95, 2.55),
        "Process Payment":          (4.95, 1.55),
        "Manage Menu Items\n(add / update / delete)": (8.05, 5.05),
        "View Reports":             (8.05, 3.8),
        "Save / Load Data":         (8.05, 2.55),
    }
    for name, (x, y) in cases.items():
        ax.add_patch(Ellipse((x, y), W_, H_, fc=BLUE, ec="#333", lw=1.3))
        ax.text(x, y, name, ha="center", va="center", fontsize=9.5)

    stick_figure(ax, 1.3, 4.6, "Waiter / Cashier")
    stick_figure(ax, 11.7, 4.6, "Manager")
    waiter_pt, manager_pt = (1.62, 4.85), (11.38, 4.85)
    waiter_cases = ["Search Records", "Display Records", "Manage Customers\n(add / update / delete)",
                    "Place Order", "Update / Cancel Order", "Generate Bill", "Process Payment"]
    manager_cases = ["Search Records", "Display Records", "Manage Menu Items\n(add / update / delete)",
                     "View Reports", "Save / Load Data"]
    for n in waiter_cases:
        x, y = cases[n]
        ax.plot([waiter_pt[0], x - W_ / 2], [waiter_pt[1], y], color="#444", lw=1.1)
    for n in manager_cases:
        x, y = cases[n]
        ax.plot([manager_pt[0], x + W_ / 2], [manager_pt[1], y], color="#444", lw=1.1)
    ax.text(6.5, 0.45, "Waiter / Cashier: daily operations (customers, orders, bills, payment).   "
            "Manager: menu, reports, saving and loading data.", ha="center", fontsize=9, color="#444")
    plt.tight_layout()
    fig.savefig("Use_Case_Diagram.png", dpi=170)
    plt.close(fig)

# ------------------------------------------------------------------ SEQUENCE
def sequence(filename, title, parts, msgs, frames=(), width=None):
    n = len(parts)
    xs = {p: 1.4 + i * (13.2 / max(1, n - 1)) * (n - 1) / n * 1.0 for i, p in enumerate(parts)}
    # even spacing
    step = 15.0 / n
    xs = {p: step / 2 + i * step for i, p in enumerate(parts)}
    top = 0.6
    gap = 0.8
    height = top + gap * (len(msgs) + 2) + 0.9
    fig, ax = plt.subplots(figsize=(15, height * 0.78))
    ax.set_xlim(0, 15); ax.set_ylim(-height, 0.4); ax.axis("off")
    ax.text(7.5, 0.15, title, ha="center", va="center", fontsize=14, fontweight="bold")
    # participant boxes + lifelines
    for p in parts:
        x = xs[p]
        ax.add_patch(FancyBboxPatch((x - 0.85, -top - 0.38), 1.7, 0.7, boxstyle="round,pad=0.02",
                                    fc=BLUE if p not in ("Waiter / Cashier",) else GREY, ec="#333", lw=1.3))
        ax.text(x, -top - 0.03, p, ha="center", va="center", fontsize=9.5, fontweight="bold")
        ax.plot([x, x], [-top - 0.4, -height + 0.35], ls=(0, (5, 4)), color="#777", lw=1)
    y_of = {}
    y = -top - 0.4 - gap * 0.9
    # frames first (drawn under arrows)
    for i, m in enumerate(msgs):
        y_of[i] = y - i * gap
    for (a, b, kind, label) in frames:
        ya, yb = y_of[a] + 0.5, y_of[b] - 0.2
        involved = [xs[p] for m in msgs[a:b + 1] for p in (m[0], m[1])]
        x1, x2 = min(involved) - 0.55, max(involved) + 0.55
        ax.add_patch(Rectangle((x1, yb), x2 - x1, ya - yb, fill=False, ec="#B04A00", lw=1.3))
        ax.add_patch(Rectangle((x1, ya - 0.28), 1.0 + 0.1 * len(kind), 0.28, fc="#FBE3CC", ec="#B04A00", lw=1.0))
        ax.text(x1 + 0.08, ya - 0.14, kind, fontsize=8.5, va="center", fontweight="bold", color="#7a3000")
        ax.text(x2 - 0.1, ya - 0.14, label, fontsize=8.5, va="center", ha="right", color="#7a3000")
    for i, (src, dst, text, style) in enumerate(msgs):
        yy = y_of[i]
        x1, x2 = xs[src], xs[dst]
        dashed = style == "return"
        if src == dst:  # self message
            ax.plot([x1, x1 + 0.55, x1 + 0.55], [yy + 0.12, yy + 0.12, yy - 0.12], color="#222", lw=1.2)
            ax.add_patch(FancyArrowPatch((x1 + 0.55, yy - 0.12), (x1 + 0.02, yy - 0.12), arrowstyle="-|>",
                                         mutation_scale=11, color="#222", lw=1.2))
            ax.text(x1 + 0.7, yy, f"{i + 1}. {text}", fontsize=8.8, va="center", ha="left")
            continue
        ax.add_patch(FancyArrowPatch((x1, yy), (x2, yy), arrowstyle="-|>" if not dashed else "->",
                                     mutation_scale=12, color="#222", lw=1.2, ls="--" if dashed else "-"))
        ax.text((x1 + x2) / 2, yy + 0.09, f"{i + 1}. {text}", fontsize=8.8, ha="center", va="bottom",
                bbox=dict(fc="white", ec="none", pad=0.6, alpha=0.9))
    plt.tight_layout()
    fig.savefig(filename, dpi=170)
    plt.close(fig)

def seq1():
    P = ["Waiter / Cashier", "main()", "Restaurant", "Order", "MenuItem*\n(Food / Beverage)", "Bill"]
    W, M, R, O, I, B = P
    msgs = [
        (W, M, "choose 6 > Place New Order", "call"),
        (M, R, "createOrder()", "call"),
        (R, W, "show customers, ask Customer ID", "return"),
        (W, R, "Customer ID", "call"),
        (R, R, "findCustomerIndex(id)  [must exist]", "call"),
        (R, O, "Order(nextOrderId, customerId)", "call"),
        (W, R, "Item ID and quantity", "call"),
        (R, I, "getPrice(), getTaxRate()   [virtual]", "call"),
        (R, O, "addItem(id, name, price, tax, qty)", "call"),
        (O, O, "calculateTotal()", "call"),
        (R, R, "orders[orderCount++] = order  (growOrders() if full)", "call"),
        (R, W, "order summary: subtotal, tax, TOTAL", "return"),
        (W, M, "choose 6 > Generate Bill (order id, discount %)", "call"),
        (M, R, "generateBill()", "call"),
        (R, B, "Bill(billId, orderId, subtotal, tax, discount%)", "call"),
        (B, B, "calculateTotal()", "call"),
        (R, O, "setStatus(BILLED)", "call"),
        (R, B, "printBill(order, customerName)", "call"),
        (R, W, "bill shown on screen (amount payable)", "return"),
    ]
    sequence("Sequence_Diagram_1_Place_Order_and_Bill.png",
             "Sequence Diagram 1 - Main Transaction: Place Order and Generate Bill",
             P, msgs, frames=[(6, 9, "loop", "[for each item, until Item ID = 0]")])

def seq2():
    P = ["Waiter / Cashier", "main()", "Restaurant", "Bill", "Order", "FileManager", "Data files"]
    W, M, R, B, O, F, D = P
    msgs = [
        (W, M, "choose 6 > Pay Bill", "call"),
        (M, R, "payBill()", "call"),
        (R, R, "findBillIndex(id), findOrderIndex(orderId)", "call"),
        (R, B, "printBill(order, customerName)", "call"),
        (W, R, "payment mode, amount received", "call"),
        (R, W, "RestaurantException: Insufficient amount", "return"),
        (R, B, "markPaid(mode)", "call"),
        (R, O, "setStatus(PAID)", "call"),
        (R, W, "Payment successful, change to return", "return"),
        (W, M, "choose 8 > Save (or Exit > save = y)", "call"),
        (M, R, "saveData()", "call"),
        (R, F, "save(*this)", "call"),
        (F, D, "write menu / customers / orders / bills", "call"),
        (F, R, "done", "return"),
        (R, W, "Saved: n items, n customers, n orders, n bills", "return"),
    ]
    sequence("Sequence_Diagram_2_Payment_and_Save.png",
             "Sequence Diagram 2 - Pay Bill and Save to File",
             P, msgs, frames=[(5, 5, "alt", "[amount < bill amount]"), (6, 8, "alt", "[else: amount >= bill amount]")])

use_case()
seq1()
seq2()
print("diagrams written")
