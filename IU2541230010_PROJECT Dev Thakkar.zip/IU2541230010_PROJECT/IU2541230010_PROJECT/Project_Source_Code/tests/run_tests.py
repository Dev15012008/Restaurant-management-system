#!/usr/bin/env python3
"""Runs the 15 test cases against the compiled program.
Each test feeds scripted keystrokes to the real executable (using a fresh copy of seed_data)
and checks the real output for the expected text. Results go to results.json + Test_Results.txt.
Usage:  python3 run_tests.py            (run from the tests folder, executable is ../restaurant)
"""
import json, os, re, shutil, subprocess, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
EXE = os.path.join(HERE, "..", "restaurant")
SEED = os.path.join(HERE, "seed_data")

# Each session = list of keystroke lines.  'expect' = substrings that must appear in the output.
TESTS = [
 dict(id="T01", op="Add menu item (Food)",
      inp="Add Record > Menu Item > Food; name 'Chole Bhature', category 'Main Course', price 150, veg = y, spice 2",
      exp="Item added with new ID 11 as Food, 5% tax, 'Veg, Medium'",
      sessions=[[1,1,1,"Chole Bhature","Main Course",150,"y",2,9,"n"]],
      expect=["Menu item added successfully", "Chole Bhature", "Veg, Medium"],
      show=[("Chole Bhature","Food","Main Course")]),
 dict(id="T02", op="Add menu item (Beverage)",
      inp="Add Record > Menu Item > Beverage; name 'Cold Coffee', category 'Beverage', price 120, 300 ml, cold = y",
      exp="Item added as Beverage with 12% tax and '300 ml, Cold'",
      sessions=[[1,1,2,"Cold Coffee","Beverage",120,300,"y",9,"n"]],
      expect=["Menu item added successfully", "Cold Coffee", "300 ml, Cold", " 12%"],
      show=[("Cold Coffee","Beverage","300 ml")]),
 dict(id="T03", op="Input validation / exception handling",
      inp="Main menu: 'abc' then 12; Add item 'Samosa' with price -5, then 'abc', then 40",
      exp="Each wrong value is rejected with an error message; the item is accepted only with price 40",
      sessions=[["abc",12,1,1,1,"Samosa","Starter",-5,"abc",40,"y",1,9,"n"]],
      expect=["Please enter a valid whole number.", "Value must be between 1 and 9.",
              "Value must be between 1 and 10000.", "Please enter a valid number.", "Samosa"],
      show=[("whole number",),("between 1 and 9",),("between 1 and 10000",),("valid number",)]),
 dict(id="T04", op="Add customer",
      inp="Add Record > Customer; name 'Neha Joshi', phone 9099912345",
      exp="Customer saved with the next free ID (4)",
      sessions=[[1,2,"Neha Joshi","9099912345",2,2,9,"n"]],
      expect=["Customer added successfully with ID 4", "Neha Joshi"],
      show=[("Customer added successfully with ID 4.",)]),
 dict(id="T05", op="Customer validation (bad phone, duplicate phone)",
      inp="Add Customer 'Test User' with phone 12345, then 9876543210 (already used)",
      exp="Short phone rejected; duplicate phone refused with message",
      sessions=[[1,2,"Test User","12345","9876543210",9,"n"]],
      expect=["Phone number must be exactly 10 digits.", "A customer with this phone number already exists (ID 1)."],
      show=[("exactly 10 digits",),("already exists (ID 1)",)]),
 dict(id="T06", op="Display records (menu)",
      inp="Display Records > Menu",
      exp="Table of all 10 seeded menu items, polymorphic Type/Tax/Details columns",
      sessions=[[2,1,9,"n"]],
      expect=["Menu (10 items)", "Paneer Tikka", "Masala Chai", "Beverage"],
      show=[("Menu (10 items)",),("Paneer Tikka","Food")]),
 dict(id="T07", op="Search (menu by category keyword, case-insensitive)",
      inp="Search Record > Menu Item > By category; keyword 'main'",
      exp="Both 'Main Course' items found (Butter Chicken, Dal Makhani)",
      sessions=[[3,1,3,"main",9,"n"]],
      expect=["Butter Chicken", "Dal Makhani", "2 item(s) found."],
      show=[("Butter Chicken","Main Course"),("Dal Makhani","Main Course"),("2 item(s) found.",)]),
 dict(id="T08", op="Search with no result",
      inp="Search Record > Menu Item > By ID; ID 99",
      exp="Message that no matching item exists (no crash)",
      sessions=[[3,1,1,99,9,"n"]],
      expect=["No matching menu items found."],
      show=[("No matching menu items found.",)]),
 dict(id="T09", op="Update record (menu price)",
      inp="Update Record > Menu Item; ID 6 (Garlic Naan), change price to 75",
      exp="Price changes from 60.00 to 75.00",
      sessions=[[4,1,6,1,75,9,"n"]],
      expect=["Updated successfully.", "75.00"],
      show=[("Updated successfully.",),("Garlic Naan","75.00")]),
 dict(id="T10", op="Main transaction - place order",
      inp="Transaction > Place Order; customer 1; items 1 x2, 3 x1, 8 x3; finish with 0",
      exp="Order 1 created; subtotal 900.00, tax 53.40, TOTAL Rs. 953.40",
      sessions=[[6,1,1,1,2,3,1,8,3,0,9,"n"]],
      expect=["Order placed successfully.", "ORDER #1", "TOTAL: Rs. 953.40"],
      show=[("ORDER #1","OPEN"),("TOTAL: Rs. 953.40",)]),
 dict(id="T11", op="Main transaction - generate bill with discount",
      inp="Place the order above, then Generate Bill for order 1 with 10% discount",
      exp="Bill 1 printed; discount 95.34; AMOUNT PAYABLE 858.06; order status BILLED",
      sessions=[[6,1,1,1,2,3,1,8,3,0,6,2,1,10,2,3,9,"n"]],
      expect=["Discount (10%)", "-95.34", "AMOUNT PAYABLE", "858.06", "BILLED"],
      show=[("Discount (10%)",),("AMOUNT PAYABLE",),("Aarav Mehta","BILLED")]),
 dict(id="T12", op="Main transaction - payment (insufficient, then correct)",
      inp="Pay Bill 1 by Cash with Rs. 500, then again with Rs. 1000",
      exp="500 refused (insufficient); 1000 accepted, change Rs. 141.94, order PAID",
      sessions=[[6,1,1,1,2,3,1,8,3,0,6,2,1,10,6,3,1,1,500,6,3,1,1,1000,2,3,9,"n"]],
      expect=["Insufficient amount.", "Payment successful via Cash. Change to return: Rs. 141.94", "PAID"],
      show=[("Insufficient amount.",),("Payment successful via Cash",)]),
 dict(id="T13", op="Cancel order and delete rules",
      inp="Order for customer 2 (item 6 x2) > cancel it; try deleting customer 2; delete order 1; delete customer 2",
      exp="Order CANCELLED; customer delete refused while orders exist; allowed after order is removed",
      sessions=[[6,1,2,6,2,0,6,4,1,"y",5,2,2,5,3,1,"y",5,2,2,"y",9,"n"]],
      expect=["Order 1 cancelled.", "Cannot delete: this customer has orders", "Order deleted.", "Customer deleted."],
      show=[("Order 1 cancelled.",),("Cannot delete: this customer has orders",),("Order deleted.",),("Customer deleted.",)]),
 dict(id="T14", op="Report",
      inp="One paid order (customer 1) and one unpaid billed order (customer 2: item 9 x4), then Report",
      exp="Revenue 858.06, outstanding 313.60, best seller Fresh Lime Soda (4), top customer Aarav Mehta",
      sessions=[[6,1,1,1,2,3,1,8,3,0,6,2,1,10,6,3,1,1,1000,
                 6,1,2,9,4,0,6,2,2,0,7,9,"n"]],
      expect=["Revenue (paid)  : Rs. 858.06", "Outstanding     : Rs. 313.60",
              "Best-selling    : Fresh Lime Soda (4 sold)", "Top customer    : Aarav Mehta"],
      show=[("Revenue (paid)",),("Outstanding",),("Best-selling",),("Top customer",)]),
 dict(id="T15", op="File persistence (close and reopen)",
      inp="Run 1: add item, customer, order and bill, exit with save. Run 2: start again, display menu and orders",
      exp="Second run loads 11 menu items, 4 customers, 1 order, 1 bill; new records are still there",
      sessions=[[1,1,1,"Chole Bhature","Main Course",150,"y",2,
                 1,2,"Kabir Nair","9123456780",
                 6,1,4,11,2,0,6,2,1,0,9,"y"],
                [2,1,2,3,9,"n"]],
      expect=["Loaded from", "11 menu items, 4 customers, 1 orders, 1 bills", "Chole Bhature", "Kabir Nair"],
      show=[("Loaded from","11 menu items, 4 customers"),("Chole Bhature","Food"),("Kabir Nair","BILLED")]),
]

def run_session(datadir, keys):
    text = "\n".join(str(k) for k in keys) + "\n"
    env = dict(os.environ, RMS_ECHO="1")
    p = subprocess.run([EXE, datadir], input=text, capture_output=True, text=True, env=env, timeout=30)
    return p.stdout.replace(datadir, "Data")      # hide the temporary folder name

def main():
    results, transcript = [], []
    os.makedirs(os.path.join(HERE, "inputs"), exist_ok=True)
    for t in TESTS:
        tmp = tempfile.mkdtemp()
        data = os.path.join(tmp, "Data")
        shutil.copytree(SEED, data)
        outputs = []
        for n, keys in enumerate(t["sessions"], 1):
            with open(os.path.join(HERE, "inputs", f"{t['id']}_run{n}.txt"), "w") as f:
                f.write("\n".join(str(k) for k in keys) + "\n")
            outputs.append(run_session(data, keys))
        full = "\n".join(outputs)
        ok = all(e in full for e in t["expect"])
        lines = [ln.strip() for ln in full.splitlines()]
        actual = []
        for keys in t["show"]:
            hit = next((ln for ln in lines if all(k in ln for k in keys)), None)
            if hit:
                hit = re.sub(r"\s+", " ", hit).strip(" |")
                if hit not in actual:
                    actual.append(hit)
        t_out = dict(id=t["id"], op=t["op"], inp=t["inp"], exp=t["exp"],
                     actual=" | ".join(actual), status="PASS" if ok else "FAIL")
        results.append(t_out)
        transcript.append("=" * 78 + f"\n{t['id']} - {t['op']}\nInput: {t['inp']}\nStatus: {t_out['status']}\n" + "=" * 78)
        for n, o in enumerate(outputs, 1):
            transcript.append(f"--- run {n} output ---\n{o}")
        shutil.rmtree(tmp)
        print(t["id"], t_out["status"])
    json.dump(results, open(os.path.join(HERE, "results.json"), "w"), indent=1)
    open(os.path.join(HERE, "Test_Results.txt"), "w").write("\n".join(transcript))
    passed = sum(r["status"] == "PASS" for r in results)
    print(f"{passed}/{len(results)} passed")

if __name__ == "__main__":
    main()
